import matplotlib.pyplot as plt
import os.path

# Naming the current directory
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'religion_datafile.txt')

datafile = open(filename, 'r',)
data = datafile.readlines()

#needs to build pie from each line before looping back
for line in data[1:]:
    
    '''reinitialize after loop is completed!!! 
    otherwise append to religions is unable to build graphs'''
    
    religions = []
    religion_labels = ['Christian','Other','Shia Muslim','Sunni Muslim']
    
    '''simplify data to only those sets with actual data
    takes line data and puts into list to be put into pie argument'''
    
    country,christian,other,shia,sunni = line.split('\t')
    religions += [christian,other,shia,sunni]
    
    #build pie charts using data from each line
    fig, ax = plt.subplots(1, 1)
    ax.pie(religions, labels = religion_labels,autopct='%.2f')
    ax.set_title('Citizens of %s by Religion' % country)
    ax.set_aspect(1)
    fig.show()
    