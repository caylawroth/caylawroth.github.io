"""
Jordan Huynh and Cayla Wroth
3.2.7 Investigating with Data
Data Project
Period 3 AP Computer Science Principles
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os.path


###
# Get the country/religion data from CSV
###
# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'religiontrends.csv')
datafile = open(filename,'r')
data = datafile.readlines()

def plot_data(filename):
    for line_number, line in enumerate(datafile):
        if line_number > 1:
                religion, Iran, Iraq, Libya, Somalia, Sudan, Syria, Yemen = line.split(',')
                x_axis_data.append(int(religion))
                countries = [Iran, Iraq, Libya, Somalia, Sudan, Syria, Yemen[:-1]]
                for i in range(7):
                    y_axis_data[i].append(int(countries[i]))
                    
        else: datafile.close()  # closes datafile after iterating through every line
        return x_axis_data, y_axis_data  # returns x- and y- coordinate data points

#uses data from csv file to create stacked bar chart
raw_data = {'country': ['Iran', 'Iraq', 'Libya', 'Somalia', 'Sudan', 'Syria', 'Yemen'],
        'shia_muslim': [90, 65, 0, 0, 0, 13, 35],
        'sunni_muslim': [8.7, 32, 96.6, 100, 100, 74, 65],
        'other': [1.3, 3, 3.4, 0, 0, 13, 0]}
df = pd.DataFrame(raw_data, columns = ['country', 'shia_muslim', 'sunni_muslim', 'other'])
df
# Create the general blog and the "subplots" i.e. the bars
f, ax1 = plt.subplots(1, figsize=(10,5))

# Set the bar width
bar_width = 0.75

# positions of the left bar-boundaries
bar_l = [i+1 for i in range(len(df['shia_muslim']))] 

# positions of the x-axis ticks (center of the bars as bar labels)
tick_pos = [i+(bar_width/2) for i in bar_l] 

# Create a bar plot, in position bar_1
ax1.bar(bar_l, 
        # using the shia_muslim data
        df['shia_muslim'], 
        # set the width
        width=bar_width,
        # with the label pre score
        label='Shia Muslim', 
        # with alpha 0.5
        alpha=0.5, 
        # with color
        color='#873aa8')

# Create a bar plot, in position bar_1
ax1.bar(bar_l, 
        # using the sunni_muslim data
        df['sunni_muslim'], 
        # set the width
        width=bar_width,
        # with shia_muslim on the bottom
        bottom=df['shia_muslim'], 
        # with the label mid score
        label='Sunni Muslim', 
        # with alpha 0.5
        alpha=0.5, 
        # with color
        color='#8e2946')

# Create a bar plot, in position bar_1
ax1.bar(bar_l, 
        # using the other data
        df['other'], 
        # set the width
        width=bar_width,
        # with shia_muslim and sunni_muslim on the bottom
        bottom=[i+j for i,j in zip(df['shia_muslim'],df['sunni_muslim'])], 
        # with the label post score
        label='Other', 
        # with alpha 0.5
        alpha=0.5, 
        # with color
        color='#a3c5e2')

# set the x ticks with names
plt.xticks(tick_pos, df['country'])

# Set the label and legends
ax1.set_ylabel("Percent of Religious Group")
ax1.set_xlabel("Banned Country")
plt.legend(loc='lower left')

# Set a buffer around the edge
plt.xlim([min(tick_pos)-bar_width, max(tick_pos)+bar_width])
plt.show()